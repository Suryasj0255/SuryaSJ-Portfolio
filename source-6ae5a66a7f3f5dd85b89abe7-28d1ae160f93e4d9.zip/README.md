# Surya S J Portfolio

Surya S J's product design portfolio, featuring AI and EdTech work, interactive case studies, career experience, and contact options.

The site uses plain HTML, CSS, and JavaScript, with GSAP, ScrollTrigger, Lenis, Three.js, and Google Fonts loaded from external CDNs. Netlify publishes the `public` directory directly without a build step.

To view locally, run `python3 -m http.server 8080 --directory public` and open `http://localhost:8080`.

The contact form uses the uploaded site's existing FormSubmit integration. That service may require the recipient to activate email delivery. The resume also supports printing to PDF; a separate resume PDF was not included in the upload.
