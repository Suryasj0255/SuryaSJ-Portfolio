# Project architecture

This is a static portfolio uploaded as a complete HTML document. Preserve the supplied design and content unless asked to change them.

- `public/index.html` contains the page, inline styles, portfolio content, and interactive JavaScript.
- `netlify.toml` publishes `public` directly. There is no package manager or build step.
- External CDNs provide fonts and animation libraries. The existing contact form sends to FormSubmit.

Make targeted changes to the HTML rather than introducing a framework. Keep metadata in the document head consistent with the portfolio. Do not place private credentials in client code. Additional static assets belong inside `public` and should use relative or root-relative URLs.
